"""
Classes for ArcGIS Services
"""
from __future__ import absolute_import
from ._layerfactory import Service

__version__ = "1.9.1"
__all__ = ["Service"]
