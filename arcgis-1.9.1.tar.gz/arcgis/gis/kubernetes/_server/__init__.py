from ._servicedir import KubeServiceDirectory
