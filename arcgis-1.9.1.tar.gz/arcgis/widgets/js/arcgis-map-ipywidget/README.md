# ArcGIS Map IPyWidget

This npm package contains all the JavaScript code that is run inside of a Jupyter notebook when using the ArcGIS API for Python to create maps. See the ArcGIS API for Python landing page for more information: https://developers.arcgis.com/python/.
