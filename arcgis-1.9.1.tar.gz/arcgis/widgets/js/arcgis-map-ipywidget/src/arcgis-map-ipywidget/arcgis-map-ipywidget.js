ArcGISMapIPyWidgetModel = require('./arcgis-map-ipywidget-model')
ArcGISMapIPyWidgetView = require('./arcgis-map-ipywidget-view')

module.exports = {
    ArcGISMapIPyWidgetModel : ArcGISMapIPyWidgetModel,
    ArcGISMapIPyWidgetView : ArcGISMapIPyWidgetView
};
