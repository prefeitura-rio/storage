// Export widget models and views, and the npm package version number.
module.exports = require('./arcgis-map-ipywidget/arcgis-map-ipywidget.js');
module.exports['version'] = require('../package.json').version;
